This folder contains code that I'm experimenting with outside of the main miniaudio library. It's just for
my own research and experimenting which I'm putting into the repository for version control purposes and
to get feedback from the community. You should not consider any of this code to be production quality.