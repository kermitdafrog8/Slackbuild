====================
sphinxcontrib-qthelp
====================

sphinxcontrib-qthelp is a sphinx extension which outputs QtHelp document.

For more details, please visit http://www.sphinx-doc.org/.

Installing
==========

Install from PyPI::

   pip install -U sphinxcontrib-qthelp

Contributing
============

See `CONTRIBUTING.rst`__

.. __: https://github.com/sphinx-doc/sphinx/blob/master/CONTRIBUTING.rst
