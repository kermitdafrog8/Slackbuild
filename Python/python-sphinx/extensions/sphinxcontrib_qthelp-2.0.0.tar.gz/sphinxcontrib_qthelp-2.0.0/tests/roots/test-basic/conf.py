from __future__ import annotations

project = 'Python'
