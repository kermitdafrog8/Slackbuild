from __future__ import annotations

project = 'need <b>"escaped"</b> project'
smartquotes = False
