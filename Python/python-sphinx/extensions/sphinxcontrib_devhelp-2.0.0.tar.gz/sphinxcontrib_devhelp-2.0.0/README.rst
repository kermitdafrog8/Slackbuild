=====================
sphinxcontrib-devhelp
=====================

sphinxcontrib-devhelp is a sphinx extension which outputs Devhelp_ document.

For more details, please visit http://www.sphinx-doc.org/.

.. _Devhelp: https://wiki.gnome.org/Apps/Devhelp

Installing
==========

Install from PyPI::

   pip install -U sphinxcontrib-devhelp

Contributing
============

See `CONTRIBUTING.rst`__

.. __: https://github.com/sphinx-doc/sphinx/blob/master/CONTRIBUTING.rst
