extensions = ['sphinxcontrib.jsmath']
jsmath_path = '/path/to/jsmath.js'
