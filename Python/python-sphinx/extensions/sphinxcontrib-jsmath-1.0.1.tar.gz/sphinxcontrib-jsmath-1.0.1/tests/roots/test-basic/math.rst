math
====

.. math::

   E = mc^2

.. math::
   :label: pythagorean

   a^2 + b^2 = c^2

.. math::
   :label:

   y > x \in 2

Referencing equation :eq:`pythagorean` and :math:numref:`pythagorean`.
