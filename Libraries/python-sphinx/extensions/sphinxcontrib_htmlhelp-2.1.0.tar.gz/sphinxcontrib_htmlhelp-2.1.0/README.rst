======================
sphinxcontrib-htmlhelp
======================

sphinxcontrib-htmlhelp is a sphinx extension which renders HTML help files.

For more details, please visit http://www.sphinx-doc.org/.

Installing
==========

Install from PyPI::

   pip install -U sphinxcontrib-htmlhelp

Contributing
============

See `CONTRIBUTING.rst`__

.. __: https://github.com/sphinx-doc/sphinx/blob/master/CONTRIBUTING.rst
