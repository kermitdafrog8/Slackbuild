from __future__ import annotations

project = 'test'
