from __future__ import annotations

project = 'Python'
html_theme = 'basic'
