#pragma once

#if defined(OS_MACOS)

    #include <string>

    extern "C" void openWebpageMacos(const char *url);
    extern "C" bool isMacosSystemDarkModeEnabled();

#endif