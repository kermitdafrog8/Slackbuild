This directory contains the Clipper library for interacting with polygons.
https://sourceforge.net/projects/polyclipping/

It is licensed under the Boost Software License, with the license text in this directory.
