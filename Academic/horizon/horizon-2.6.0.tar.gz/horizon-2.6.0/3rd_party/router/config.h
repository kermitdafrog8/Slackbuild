#pragma once

#include <cmath>
#include <climits>
#define _(x) (x)
