#pragma once

#include "wx_compat.h"
#include "eda_units.h"

wxString MessageTextFromValue(EDA_UNITS aUnits, int aValue);
