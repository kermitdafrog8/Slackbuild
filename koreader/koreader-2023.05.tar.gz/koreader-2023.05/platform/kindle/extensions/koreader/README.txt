TITLE: KOReader

CONTAINS: KUAL files for installation in /mnt/us/extensions/

REF: Main KUAL thread http://www.mobileread.com/forums/showthread.php?t=203326

UPSTREAM SOURCE: https://github.com/koreader/koreader

SUPPORTS:
DX Yes
K3 Yes
K4 Yes
Touch Yes
PW Yes
PW2 Yes
KT2 Yes
Voyage Yes
PW3 Yes
KOA Yes
KT3 Yes
KOA2 Yes
PW4 Yes
KT4 Yes

REQUIRES: koreader

ARCHIVAL LINK:

ORIGINAL AUTHOR: KOReader development team

NOTES: this is the successor of KindlePDFviewer for devices with touch input
support. Support for keyboard input is to be done, use the legacy
KindlePDFviewer or Librerator for this. Report issues and bugs on github.
