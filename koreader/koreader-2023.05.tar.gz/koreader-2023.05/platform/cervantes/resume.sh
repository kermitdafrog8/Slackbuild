#! /bin/sh

echo 0 >/sys/power/state-extended

