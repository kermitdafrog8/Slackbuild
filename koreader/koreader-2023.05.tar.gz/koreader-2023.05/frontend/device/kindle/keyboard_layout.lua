return {
    [1] = {
        "Q", "W", "E", "R", "T", "Y", "U", "I", "Q", "P",
    },
    [2] = {
        "A", "S", "D", "F", "G", "H", "J", "K", "L", "Del",
    },
    [3] = {
        "Z", "X", "C", "V", "B", "N", "M", ".", "Sym", "Enter",
    },
    [4] = {
        "Shift", "Alt", "space", "Aa", "Home", "Back",
    },
}
