local _ = require("gettext")
return {
    name = "batterystat",
    fullname = _("Battery statistics"),
    description = _([[Collects and displays battery statistics.]]),
}
